Użyta wersja Python 3.9.4.
Wszystko jest sprowadzone do jednego pliku wykonywalnego.
W source są również pobrane biblioteki z których korzystam.
Założenia:
-Bramki wejsciowe 7-8,7-9,8-8 (Jeżeli w ciagu dnia pracownik wyjdzie z pracy którąś z tych bramek 
wtedy czas do ponownego zarejestrowania identyfikatora nie będzie naliczany)
-Wpisy w pliku są posortowane rosnąco (tak jak bramki rejestrowały użycie identyfikatora)
-Jeżeli pracownik w tygodniu był naprzykład tylko 2 dni, to tylko dla tych 2 dni naliczy czas pracy i nadgodzin
